#ifndef NTP_TIMER_H
#define NTP_TIMER_H

extern	void	timer_clr_stats(void);

#endif	/* NTP_TIMER_H */
